#!/usr/bin/env python3
"""Run one bounded Round13 B QSA Decode smoke or request arm."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import time


ROLES = {
    217: ("baseline", "smoke", "A"),
    218: ("candidate", "smoke", "B"),
    219: ("baseline", "request", "A"),
    220: ("candidate", "request", "A"),
    221: ("candidate", "request", "B"),
    222: ("baseline", "request", "B"),
}
WORKLOADS = {
    "W0": ("round10", "edge64", 2),
    "W1": ("round11", "edge128", 16),
    "W2": ("round11", "edge128", 128),
    "W3": ("round11", "edge512", 16),
    "W4": ("round10", "edge64", 32),
}
QSA_LAYERS = list(range(3, 48, 4))


def save(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def read_jsonl(path):
    path = Path(path)
    if not path.exists():
        return []
    raw = path.read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise RuntimeError(f"unterminated {path.name}")
    return [json.loads(line) for line in raw.splitlines()]


def request(rid, ids, tokens, *, stream, ignore_eos):
    return {
        "rid": rid,
        "input_ids": list(ids),
        "stream": stream,
        "sampling_params": {
            "temperature": 0,
            "top_p": 1,
            "sampling_seed": 20260920,
            "max_new_tokens": tokens,
            "ignore_eos": ignore_eos,
        },
        "return_logprob": True,
        "logprob_start_len": -1,
    }


def performance_schedule(fixtures, version, implementation, block):
    rows = []
    for workload, (source, case_id, decode_tokens) in WORKLOADS.items():
        case = fixtures[source]["cases"][case_id]
        for phase, repeat in (
            ("warmup", 0),
            ("measurement", 1),
            ("measurement", 2),
            ("measurement", 3),
        ):
            rid = (
                f"r13-b-v{version}-{implementation}-{block.lower()}-"
                f"{workload.lower()}-{phase}-{repeat}"
            )
            rows.append(
                {
                    "workload": workload,
                    "case_id": case_id,
                    "phase": phase,
                    "repeat": repeat,
                    "input_tokens": len(case["input_ids"]),
                    "decode_tokens": decode_tokens,
                    "request": request(
                        rid,
                        case["input_ids"],
                        decode_tokens,
                        stream=True,
                        ignore_eos=True,
                    ),
                }
            )
    return rows


def smoke_schedule(fixtures, version, implementation):
    cases = fixtures["round11"]["cases"]
    definitions = [
        ("canary_marker", "quality", 32, None),
        ("canary_math391", "quality", 32, None),
        ("canary_json", "quality", 32, None),
        ("canary_quote", "quality", 32, None),
        ("canary_transform", "quality", 32, None),
        ("edge128", "multi_step", 32, {"kind": "multi_step", "minimum_tokens": 32}),
        ("cancel256", "cancel", 16, {"kind": "abort"}),
        ("canary_json", "reuse", 32, None),
    ]
    rows = []
    for case_id, phase, tokens, override in definitions:
        case = cases[case_id]
        rid = f"r13-b-v{version}-{implementation}-smoke-{case_id}-{phase}"
        rows.append(
            {
                "case_id": case_id,
                "phase": phase,
                "validator": override or case["validator"],
                "input_tokens": len(case["input_ids"]),
                "decode_tokens": tokens,
                "request": request(
                    rid,
                    case["input_ids"],
                    tokens,
                    stream=phase == "cancel",
                    ignore_eos=phase == "multi_step",
                ),
            }
        )
    return rows


def validate_qsa(request_id, events, implementation):
    rows = [
        row
        for row in events
        if row.get("status") == "CONTEXT_REFERENCE_QSA_DISPATCH"
        and row.get("request_id") == request_id
    ]
    vector = sorted(
        {row.get("layer") for row in rows if row.get("strategy") == "VECTORIZED"}
    )
    decode_strategy = (
        "DIRECT_BF16_ROW" if implementation == "candidate" else "ROW"
    )
    decode = sorted(
        {
            row.get("layer")
            for row in rows
            if row.get("strategy") == decode_strategy
        }
    )
    if vector != QSA_LAYERS or decode != QSA_LAYERS:
        raise RuntimeError(
            f"QSA identity missing: prefill={vector}, {decode_strategy}={decode}"
        )
    unexpected = sorted(
        {
            row.get("strategy")
            for row in rows
            if row.get("strategy") not in {"VECTORIZED", decode_strategy}
        }
    )
    if unexpected:
        raise RuntimeError(f"unexpected QSA strategy {unexpected}")
    return {
        "vector_layers": vector,
        "decode_layers": decode,
        "decode_strategy": decode_strategy,
        "dispatch_count": len(rows),
    }


def validate_ple(request_id, events):
    if not any(row.get("status") == "PLE_ASYNC_BOUND" for row in events):
        raise RuntimeError("PLE ASYNC binding missing")
    rows = [
        row
        for row in events
        if row.get("status") == "PLE_BATCH_DRAINED"
        and row.get("request_id") == request_id
    ]
    if not rows or not any(row.get("async_engaged") is True for row in rows):
        raise RuntimeError("request did not engage and drain PLE ASYNC")
    return {
        "drained": len(rows),
        "async": sum(row.get("async_engaged") is True for row in rows),
    }


def run(version, implementation, mode, block, out, fixture10_path, fixture11_path):
    from round11_t4_driver import consume_stream, post, validate_hybrid_path
    from round10_t1_driver import run_cancel
    from round10_t1_protocol import validate_cancel_receipt, validate_response

    if ROLES.get(version) != (implementation, mode, block):
        raise ValueError("Round13 B version/role mismatch")
    out = Path(out)
    result_path = out / "round13-b-raw.json"
    if result_path.exists():
        raise FileExistsError(result_path)
    fixtures = {
        "round10": json.loads(Path(fixture10_path).read_text()),
        "round11": json.loads(Path(fixture11_path).read_text()),
    }
    generation_limit = 8 if mode == "smoke" else 20
    abort_limit = 1 if mode == "smoke" else 0
    report = {
        "schema": 1,
        "status": "RUNNING",
        "stage": "ROUND13_B_QSA_DECODE",
        "version": version,
        "implementation": implementation,
        "mode": mode,
        "block": block,
        "profiler": "OFF",
        "profile_threshold": 513,
        "default_threshold": 129,
        "generation_budget": generation_limit,
        "generation_attempts": 0,
        "abort_controls": 0,
        "automatic_retries": 0,
        "results": [],
        "measurement_windows": {},
    }
    pending_cancel = None
    try:
        if mode == "smoke":
            schedule = smoke_schedule(fixtures, version, implementation)
            for row in schedule:
                report["generation_attempts"] += 1
                rid = row["request"]["rid"]
                started = time.monotonic_ns()
                if row["phase"] == "cancel":
                    report["abort_controls"] += 1
                    pending_cancel = run_cancel(row, out, post_fn=post)
                    report["results"].append(
                        {
                            "case_id": row["case_id"],
                            "phase": "cancel",
                            "request_id": rid,
                            "e2e_seconds": (
                                time.monotonic_ns() - started
                            )
                            / 1e9,
                            "cancel_status": pending_cancel["status"],
                        }
                    )
                    save(result_path, report)
                    continue
                with post("/generate", row["request"], 1800) as response:
                    value = json.load(response)
                validated = validate_response(row, value)
                path = validate_hybrid_path(
                    rid,
                    read_jsonl(out / "hybrid-path.jsonl"),
                    read_jsonl(out / "layerwise-events.jsonl"),
                )
                item = {
                    "case_id": row["case_id"],
                    "phase": row["phase"],
                    "request_id": rid,
                    "e2e_seconds": (time.monotonic_ns() - started) / 1e9,
                    "quality_pass": True,
                    "validated": validated,
                    "path": path,
                    "qsa": validate_qsa(
                        rid,
                        read_jsonl(out / "context-reference-events.jsonl"),
                        implementation,
                    ),
                    "ple": validate_ple(
                        rid, read_jsonl(out / "ple-async-events.jsonl")
                    ),
                }
                report["results"].append(item)
                if row["phase"] == "reuse":
                    if pending_cancel is None:
                        raise RuntimeError("reuse lacks preceding cancel")
                    pending_cancel["reuse"] = {
                        "request_id": rid,
                        "validator_passed": True,
                        "output_ids": validated["output_ids"],
                    }
                    pending_cancel["status"] = (
                        "PASS_HYBRID_MIDPREFILL_CANCEL_AND_REUSE"
                    )
                    validate_cancel_receipt(pending_cancel)
                    save(out / "round13-b-cancel-receipt.json", pending_cancel)
                    report["results"][-2]["cancel_status"] = pending_cancel[
                        "status"
                    ]
                    pending_cancel = None
                save(result_path, report)
        else:
            schedule = performance_schedule(
                fixtures, version, implementation, block
            )
            for workload in WORKLOADS:
                group = [row for row in schedule if row["workload"] == workload]
                measurement_started = None
                measurement_ended = None
                measured_tokens = 0
                successes = 0
                for row in group:
                    report["generation_attempts"] += 1
                    rid = row["request"]["rid"]
                    if row["phase"] == "measurement" and measurement_started is None:
                        measurement_started = time.monotonic_ns()
                    started = time.monotonic_ns()
                    with post("/generate", row["request"], 1800) as response:
                        stream = consume_stream(response, row["decode_tokens"])
                    ended = time.monotonic_ns()
                    path = validate_hybrid_path(
                        rid,
                        read_jsonl(out / "hybrid-path.jsonl"),
                        read_jsonl(out / "layerwise-events.jsonl"),
                    )
                    if stream["output_ids"][:2] != [3897, 248046]:
                        raise RuntimeError("performance workload lost ACK prefix")
                    item = {
                        **{
                            key: row[key]
                            for key in (
                                "workload",
                                "case_id",
                                "phase",
                                "repeat",
                                "input_tokens",
                                "decode_tokens",
                            )
                        },
                        "request_id": rid,
                        **stream,
                        "ttft_seconds": (
                            stream["token_arrival_monotonic_ns"][0] - started
                        )
                        / 1e9,
                        "e2e_seconds": (ended - started) / 1e9,
                        "tpot_seconds": (
                            (
                                stream["token_arrival_monotonic_ns"][-1]
                                - stream["token_arrival_monotonic_ns"][0]
                            )
                            / (len(stream["output_ids"]) - 1)
                            / 1e9
                            if len(stream["output_ids"]) > 1
                            else None
                        ),
                        "path": path,
                        "qsa": validate_qsa(
                            rid,
                            read_jsonl(out / "context-reference-events.jsonl"),
                            implementation,
                        ),
                        "ple": validate_ple(
                            rid, read_jsonl(out / "ple-async-events.jsonl")
                        ),
                    }
                    del item["token_arrival_monotonic_ns"]
                    report["results"].append(item)
                    if row["phase"] == "measurement":
                        measured_tokens += stream["completion_tokens"]
                        successes += 1
                        measurement_ended = ended
                    save(result_path, report)
                seconds = (measurement_ended - measurement_started) / 1e9
                report["measurement_windows"][workload] = {
                    "seconds": seconds,
                    "successful_requests": successes,
                    "output_tokens": measured_tokens,
                    "serial_output_tokens_per_second": measured_tokens / seconds,
                    "requests_per_second": successes / seconds,
                }
        if (
            report["generation_attempts"] != generation_limit
            or report["abort_controls"] != abort_limit
            or pending_cancel is not None
        ):
            raise RuntimeError("Round13 B schedule/budget incomplete")
        report["status"] = (
            "PASS_ROUND13_B_SMOKE_RAW"
            if mode == "smoke"
            else "PASS_ROUND13_B_REQUEST_RAW"
        )
        save(result_path, report)
        return report
    except BaseException as error:
        report.update(
            status="FAIL_ROUND13_B_MODEL_DRIVER",
            error=f"{type(error).__name__}: {error}",
        )
        save(result_path, report)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", type=int, required=True)
    parser.add_argument("--implementation", choices=("baseline", "candidate"), required=True)
    parser.add_argument("--mode", choices=("smoke", "request"), required=True)
    parser.add_argument("--block", choices=("A", "B"), required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--fixture10", type=Path, required=True)
    parser.add_argument("--fixture11", type=Path, required=True)
    args = parser.parse_args()
    result = run(
        args.version,
        args.implementation,
        args.mode,
        args.block,
        args.out,
        args.fixture10,
        args.fixture11,
    )
    print(result["status"], args.implementation, args.mode, args.block, flush=True)


if __name__ == "__main__":
    main()
