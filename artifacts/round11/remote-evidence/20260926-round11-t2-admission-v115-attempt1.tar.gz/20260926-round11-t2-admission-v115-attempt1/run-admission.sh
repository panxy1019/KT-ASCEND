#!/usr/bin/env bash
set -eu
run_dir=/mnt/data1/kt-round9/evidence/20260926-round11-t2-admission-v115-attempt1
python3 "$run_dir/round10_admission.py" sample --output "$run_dir/discovery.json"
python3 "$run_dir/round10_admission.py" sample --output "$run_dir/validation.json"
python3 "$run_dir/round10_admission.py" validate --discovery "$run_dir/discovery.json" --validation "$run_dir/validation.json" --output "$run_dir/admission.json"
